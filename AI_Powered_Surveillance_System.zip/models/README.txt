Place YOLOv8 model files here (e.g., yolov8_weapon.pt)
