# AI-Powered Surveillance System

## Description
This project detects and tracks threats using YOLOv8, DeepSORT, and Flask.
